// Seleciona os elementos do jogo
const playerPaddle = document.getElementById('playerPaddle');
const aiPaddle = document.getElementById('aiPaddle');
const ball = document.getElementById('ball');
const gameArea = document.getElementById('gameArea');
const playerScoreDisplay = document.getElementById('playerScore');
const aiScoreDisplay = document.getElementById('aiScore');

// Propriedades do jogo
const gameWidth = gameArea.offsetWidth;
const gameHeight = gameArea.offsetHeight;
const paddleHeight = playerPaddle.offsetHeight;
const paddleWidth = playerPaddle.offsetWidth;
let playerPaddleY = (gameHeight - paddleHeight) / 2;
let aiPaddleY = (gameHeight - paddleHeight) / 2;
let ballX = gameWidth / 2;
let ballY = gameHeight / 2;
let ballSpeedX = 3;
let ballSpeedY = 3;
let playerScore = 0;
let aiScore = 0;
const aiSpeed = 4;

// Função para atualizar as posições no jogo
function updateGame() {
    ballX += ballSpeedX;
    ballY += ballSpeedY;

    if (ballY <= 0 || ballY >= gameHeight - ball.offsetHeight) {
        ballSpeedY = -ballSpeedY;
    }

    if (ballX <= paddleWidth) {
        if (ballY > playerPaddleY && ballY < playerPaddleY + paddleHeight) {
            ballSpeedX = -ballSpeedX;
            ballX = paddleWidth;
        }
    }

    if (ballX >= gameWidth - paddleWidth - ball.offsetWidth) {
        if (ballY > aiPaddleY && ballY < aiPaddleY + paddleHeight) {
            ballSpeedX = -ballSpeedX;
            ballX = gameWidth - paddleWidth - ball.offsetWidth;
        }
    }

    if (ballX <= 0) {
        aiScore++;
        updateScore();
        resetBall();
    } else if (ballX >= gameWidth - ball.offsetWidth) {
        playerScore++;
        updateScore();
        resetBall();
    }

    playerPaddle.style.top = playerPaddleY + 'px';

    const aiPaddleCenter = aiPaddleY + paddleHeight / 2;
    if (aiPaddleCenter < ballY - 10) {
        aiPaddleY += aiSpeed;
    } else if (aiPaddleCenter > ballY + 10) {
        aiPaddleY -= aiSpeed;
    }

    if (aiPaddleY < 0) {
        aiPaddleY = 0;
    } else if (aiPaddleY > gameHeight - paddleHeight) {
        aiPaddleY = gameHeight - paddleHeight;
    }

    aiPaddle.style.top = aiPaddleY + 'px';

    ball.style.left = ballX + 'px';
    ball.style.top = ballY + 'px';
}

function updateScore() {
    playerScoreDisplay.textContent = playerScore;
    aiScoreDisplay.textContent = aiScore;
}

function resetBall() {
    ballX = gameWidth / 2;
    ballY = gameHeight / 2;
    ballSpeedX = -ballSpeedX;
    ballSpeedY = 3 * (Math.random() > 0.5 ? 1 : -1);
}

gameArea.addEventListener('mousemove', (e) => {
    const relativeY = e.clientY - gameArea.getBoundingClientRect().top;
    playerPaddleY = relativeY - paddleHeight / 2;

    if (playerPaddleY < 0) {
        playerPaddleY = 0;
    } else if (playerPaddleY > gameHeight - paddleHeight) {
        playerPaddleY = gameHeight - paddleHeight;
    }
});

setInterval(updateGame, 16);
